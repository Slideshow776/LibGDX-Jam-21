package no.sandramoen.libgdxjam21.actors.particles;

public class BridgeBreakEffect extends ParticleActor {
    public BridgeBreakEffect() {
        super("effects/bridgeBreak.pfx");
    }
}
